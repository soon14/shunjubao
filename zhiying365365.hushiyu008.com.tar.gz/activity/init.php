<?php
include_once dirname ( dirname ( __FILE__ ) ) . DIRECTORY_SEPARATOR . 'init.php';
