<?php
define("WEBSCAN_KEY", "3cdda1f2ed459040eea2080d241f3412");
define("WEBSCAN_VERSION", "1.6");
date_default_timezone_set('GMT');
ini_set('display_errors', '0');
?>
