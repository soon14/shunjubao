<?php
include_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . '_LOCAL'. DIRECTORY_SEPARATOR .'local.inc.php';
include_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'function.inc.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'JSON.php';