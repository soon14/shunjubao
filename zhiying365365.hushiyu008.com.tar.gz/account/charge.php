<?php
/**
 * 账户充值
 */ 
include_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'init.php';


?>