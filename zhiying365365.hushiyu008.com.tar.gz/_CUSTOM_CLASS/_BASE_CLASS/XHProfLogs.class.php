<?php
class XHProfLogs extends DBAbstract {
    protected $tableName = 'xhprof_logs';
}