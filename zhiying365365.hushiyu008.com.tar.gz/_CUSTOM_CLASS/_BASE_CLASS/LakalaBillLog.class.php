<?php
class LakalaBillLog extends DBAbstract {
	protected $tableName = 'lakala_bill_log';
	
}