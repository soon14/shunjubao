<?PHP
//数据库
define("MYSQL_TABLEPRE", 'q_');	// 数据库表前缀
$GLOBALS["TABLE_NAME_INC"] = "q_";//数据表前辍
##########UCENTER的数据库配置参数##########
$GLOBALS['MYSQL_HOST'] = "localhost";//主机地址
$GLOBALS['MYSQL_USER'] = "root";//用户名
$GLOBALS['MYSQL_PASS'] = "meijun820526^&LKASI";//密码
$GLOBALS['MYSQL_DB'] = "zhiying_quan";//数据库名称
$GLOBALS['MYSQL_LOG'] = "";//日志地址
define('COOKIE_PATH', '/');//cookie路径
define('COOKIE_DOMAIN', '');//cookie作用域
?>